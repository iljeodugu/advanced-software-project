﻿namespace Project_Server
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.path_text_box = new System.Windows.Forms.TextBox();
            this.findPath = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.server_text_box = new System.Windows.Forms.TextBox();
            this.client_text_list = new System.Windows.Forms.ListView();
            this.label3 = new System.Windows.Forms.Label();
            this.check_text = new System.Windows.Forms.Button();
            this.check_file = new System.Windows.Forms.Button();
            this.server_on = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label4 = new System.Windows.Forms.Label();
            this.ip_text_box = new System.Windows.Forms.TextBox();
            this.port_text_box = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "서버 폴더 경로 :";
            // 
            // path_text_box
            // 
            this.path_text_box.Enabled = false;
            this.path_text_box.Location = new System.Drawing.Point(151, 104);
            this.path_text_box.Name = "path_text_box";
            this.path_text_box.Size = new System.Drawing.Size(322, 25);
            this.path_text_box.TabIndex = 1;
            // 
            // findPath
            // 
            this.findPath.Location = new System.Drawing.Point(488, 101);
            this.findPath.Name = "findPath";
            this.findPath.Size = new System.Drawing.Size(81, 31);
            this.findPath.TabIndex = 2;
            this.findPath.Text = "경로설정";
            this.findPath.UseVisualStyleBackColor = true;
            this.findPath.Click += new System.EventHandler(this.findPath_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Server Log";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(583, 101);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 31);
            this.button1.TabIndex = 4;
            this.button1.Text = "폴더열기";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // server_text_box
            // 
            this.server_text_box.Location = new System.Drawing.Point(25, 176);
            this.server_text_box.Multiline = true;
            this.server_text_box.Name = "server_text_box";
            this.server_text_box.Size = new System.Drawing.Size(343, 403);
            this.server_text_box.TabIndex = 5;
            // 
            // client_text_list
            // 
            this.client_text_list.Location = new System.Drawing.Point(367, 176);
            this.client_text_list.Name = "client_text_list";
            this.client_text_list.Size = new System.Drawing.Size(298, 403);
            this.client_text_list.TabIndex = 6;
            this.client_text_list.UseCompatibleStateImageBehavior = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(371, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "접속 목록";
            // 
            // check_text
            // 
            this.check_text.Location = new System.Drawing.Point(374, 594);
            this.check_text.Name = "check_text";
            this.check_text.Size = new System.Drawing.Size(130, 34);
            this.check_text.TabIndex = 8;
            this.check_text.Text = "필기확인";
            this.check_text.UseVisualStyleBackColor = true;
            // 
            // check_file
            // 
            this.check_file.Location = new System.Drawing.Point(525, 594);
            this.check_file.Name = "check_file";
            this.check_file.Size = new System.Drawing.Size(130, 34);
            this.check_file.TabIndex = 9;
            this.check_file.Text = "파일확인";
            this.check_file.UseVisualStyleBackColor = true;
            // 
            // server_on
            // 
            this.server_on.Location = new System.Drawing.Point(25, 621);
            this.server_on.Name = "server_on";
            this.server_on.Size = new System.Drawing.Size(174, 46);
            this.server_on.TabIndex = 10;
            this.server_on.Text = "서버 켜기";
            this.server_on.UseVisualStyleBackColor = true;
            this.server_on.Click += new System.EventHandler(this.server_on_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "IP :";
            // 
            // ip_text_box
            // 
            this.ip_text_box.Location = new System.Drawing.Point(67, 19);
            this.ip_text_box.Name = "ip_text_box";
            this.ip_text_box.Size = new System.Drawing.Size(344, 25);
            this.ip_text_box.TabIndex = 12;
            // 
            // port_text_box
            // 
            this.port_text_box.Location = new System.Drawing.Point(510, 19);
            this.port_text_box.Name = "port_text_box";
            this.port_text_box.Size = new System.Drawing.Size(92, 25);
            this.port_text_box.TabIndex = 14;
            this.port_text_box.Text = "7777";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(455, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 15);
            this.label5.TabIndex = 13;
            this.label5.Text = "Port : ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(434, 61);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(27, 25);
            this.textBox1.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(376, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "날짜 : ";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(217, 61);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(126, 25);
            this.textBox2.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(129, 64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 15);
            this.label7.TabIndex = 17;
            this.label7.Text = "수업 이름 :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(467, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 15);
            this.label8.TabIndex = 19;
            this.label8.Text = "월";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(528, 64);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(22, 15);
            this.label9.TabIndex = 21;
            this.label9.Text = "일";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(495, 61);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(27, 25);
            this.textBox3.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 686);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.port_text_box);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ip_text_box);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.server_on);
            this.Controls.Add(this.check_file);
            this.Controls.Add(this.check_text);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.client_text_list);
            this.Controls.Add(this.server_text_box);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.findPath);
            this.Controls.Add(this.path_text_box);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Shared Memory Server";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox path_text_box;
        private System.Windows.Forms.Button findPath;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox server_text_box;
        private System.Windows.Forms.ListView client_text_list;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button check_text;
        private System.Windows.Forms.Button check_file;
        private System.Windows.Forms.Button server_on;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ip_text_box;
        private System.Windows.Forms.TextBox port_text_box;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    }
}

