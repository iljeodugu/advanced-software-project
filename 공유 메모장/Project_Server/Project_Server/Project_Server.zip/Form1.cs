﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Project_class;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace Project_Server
{
    delegate void del(int a);
    
    public partial class Form1 : Form
    {
        private NetworkStream[] m_NetStream;
        private bool[] Network_start;

        private TcpListener[] m_Listener;
        private Thread[] m_Thread;
        private Thread request;
        private bool request_start = false;
        private bool[] thread_start;//스레드 꺼졋는지 확인
        private bool[] m_ClientOn;
        private bool[] connect_peopel;//접속한 인원 체크
        int people_count;
        int server_count;//접속한 사람 목록
        private bool[] mutex;

        private string path; //파일 저장 경로

        public Form1()
        {
            InitializeComponent();
            people_count = 0;
            m_NetStream = new NetworkStream[32];
            m_Listener = new TcpListener[32];
            m_Thread = new Thread[32];  
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            client_text_list.View = View.Details;
            client_text_list.Columns.Add("번호", 40, HorizontalAlignment.Center);
            client_text_list.Columns.Add("이름", 70, HorizontalAlignment.Center);
            client_text_list.Columns.Add("상태", 150, HorizontalAlignment.Center);
            server_count = 0;
            people_count = 0;
            m_ClientOn = new bool[32];
            thread_start = new bool[32];
            Network_start = new bool[32];
            connect_peopel = new bool[32];
            mutex = new bool[32];
            for (int i = 0; i < 32; i++)
            {
                Network_start[i] = false;
                thread_start[i] = false;
                connect_peopel[i] = false;
                mutex[i] = true;
            }

            ip_text_box.Text = Get_myIp();
        }

        private void server_on_Click(object sender, EventArgs e)
        {
            if (server_on.Text == "서버 켜기")
            {
                m_Thread[server_count] = new Thread(new ThreadStart(server_run));
                request = new Thread(new ThreadStart(Request));
                request.Start();
                request_start = true;
                m_Thread[server_count].Start();
                thread_start[server_count] = true;
                server_on.Text = "서버 끄기";
                server_on.ForeColor = Color.Red;
                port_text_box.Enabled = false;
                ip_text_box.Enabled = false;
            }
            else
            {
                server_on.Text = "서버 켜기";
                server_stop();
                server_on.ForeColor = Color.Black;
                port_text_box.Enabled = true;
                ip_text_box.Enabled = true;
            }
        }

        private void Request()
        {
            int request_count = 0;
            byte[] sendBuffer = new byte[1024 * 8];
            Thread.Sleep(1000);
            string name = null;
            while (true)
            {
                while(true)
                {
                    request_count++;
                    if (request_count == 32)
                        request_count = 0;
                    if (connect_peopel[request_count])
                    {
                        
                        for(int i = 0; i <32; i ++)
                        {
                            if(client_text_list.Items[i].SubItems[0].Text == request_count.ToString())
                            {
                                name = client_text_list.Items[i].SubItems[1].Text;
                                break;
                            }
                        }
                        server_text_box.AppendText(name + "님의 필기 업데이트 \n");
                        break;
                    }
                    Thread.Sleep(100);
                }
                while (!mutex[request_count]) ;
                mutex[request_count] = false;
                fileCheck fCheck = new fileCheck();
                fCheck.Type = (int)FileDataType.파일체크;
                fCheck.fileNeed = 0;
                fCheck.fileNumber = request_count;//여기서는 유저 인덱스 박자

                sendBuffer = FileData.Serialize(fCheck);
                m_NetStream[request_count].Write(sendBuffer, 0, sendBuffer.Length);
                m_NetStream[request_count].Flush();
                Thread.Sleep(1000);
            }
        }

        private void server_run()//서버를 열고 갯수만큼 가지고 있자.
        {
            int count = server_count;
            byte[] sendBuffer = new byte[1024 * 8];
            byte[] readBuffer = new byte[1024 * 8];
            m_Listener[count] = new TcpListener(Convert.ToInt32(port_text_box.Text));
            this.m_Listener[0].Start();//단일 리스너로 하면 되는거 같은데 잘모르겟다.
            m_ClientOn[count] = false;
 
            Socket Client = m_Listener[0].AcceptSocket();//이것도 연결요청 대기
            server_count++;
            people_count++;
            m_Thread[server_count] = new Thread(new ThreadStart(server_run));
            m_Thread[server_count].Start();

            if (Client.Connected)
            {
                m_ClientOn[count] = true;
                m_NetStream[count] = new NetworkStream(Client);
                connect_peopel[count] = true;
                Network_start[count] = false;
            }

            while (m_ClientOn[count])
            {
                try
                {
                    m_NetStream[count].Read(readBuffer, 0, readBuffer.Length);
                }
                catch
                {
                    m_ClientOn[count] = false;
                    m_NetStream[count] = null;
                }

                FileData temp = (FileData)FileData.Deserialize(readBuffer);

                switch ((int)temp.Type)
                {
                    case (int)FileDataType.로그인:
                        {
                            login log = (login)FileData.Deserialize(readBuffer);
                            if (log.logout)
                            {
                                int check = -1;
                                m_ClientOn[count] = false;
                                for (int i = 0; i < 32; i++)
                                {
                                    if(client_text_list.Items[i].SubItems[1].Text == log.id)
                                    {
                                        check = i;
                                        break;
                                    }
                                }
                                server_text_box.AppendText(client_text_list.Items[check].SubItems[1].Text + "님이 로그아웃 하셧습니다.\n");
                                connect_peopel[Convert.ToInt32(client_text_list.Items[check].SubItems[0].Text)] = false;
                                client_text_list.Items.RemoveAt(check);

                                listItem removeItem = new listItem();
                                removeItem.index = check;
                                removeItem.Type = (int)FileDataType.접속목록;
                                sendBuffer = FileData.Serialize(removeItem);
                                for (int i = 0; i < 32; i++)
                                {
                                    if (connect_peopel[i])
                                    {
                                        m_NetStream[i].Write(sendBuffer, 0, sendBuffer.Length);
                                        this.m_NetStream[i].Flush();
                                    }
                                }
                                people_count--;
                                break;
                            }
                            ListViewItem item;
                            string[] itemStr = new string[3];
                            itemStr[0] = count.ToString();
                            itemStr[1] = log.id;
                            itemStr[2] = "접속중...";
                            item = new ListViewItem(itemStr);
                            client_text_list.Items.Add(item);
                            server_text_box.AppendText(log.id + "님이 로그인 하셧습니다.\n");

                            listItem listitem = new listItem();
                            listitem.list = itemStr;
                            listitem.index = -1;
                            listitem.Type = (int)FileDataType.접속목록;
                            sendBuffer = FileData.Serialize(listitem);
                            
                            for (int i = 0; i < 32; i++)
                            {
                                if (connect_peopel[i] && i != count)
                                {
                                    m_NetStream[i].Write(sendBuffer, 0, sendBuffer.Length);
                                    this.m_NetStream[i].Flush();
                                }
                            }
                            listitem.first = true;
                            for(int i = 0; i < people_count; i ++)
                            {
                                itemStr[0] = client_text_list.Items[i].SubItems[0].Text;
                                itemStr[1] = client_text_list.Items[i].SubItems[1].Text;
                                itemStr[2] = client_text_list.Items[i].SubItems[2].Text;
                                listitem.list = itemStr;
                                sendBuffer = FileData.Serialize(listitem);
                                m_NetStream[count].Write(sendBuffer, 0, sendBuffer.Length);
                                m_NetStream[count].Flush();
                                Thread.Sleep(100);
                            }

                            break;
                        }
                    case (int)FileDataType.텍스트파일:
                        {
                            textFile tFile = (textFile)FileData.Deserialize(readBuffer);
                            FileStream fStream = new FileStream(path + "\\" + tFile.userName + ".txt", FileMode.Create, FileAccess.Write);
                            StreamWriter fWriter = new StreamWriter(fStream);
                            fWriter.Write(tFile.text);
                            mutex[tFile.userIndex] = true;
                            fWriter.Close();
                            fStream.Close();
                            break;
                        }
                    case (int)FileDataType.파일:
                        {
                            break;
                        }
                    case (int)FileDataType.접속목록:
                        {
                            break;
                        }
                    case (int)FileDataType.파일체크:
                        {
                            string userName = null;
                            string data;
                            FileStream fStream;
                            fileCheck fileCheck = (fileCheck)FileData.Deserialize(readBuffer);
                            for (int i = 0; i < 32; i ++)
                            {
                                if (Convert.ToInt32(client_text_list.Items[i].SubItems[0].Text) == fileCheck.fileNumber)
                                {
                                    userName = client_text_list.Items[i].SubItems[1].Text;
                                    break;
                                }
                            }

                            if ( fileCheck.fileNeed ==0 )//파일이 text 라면
                            {
                                while (!mutex[count]);
                                mutex[count] = false;

                                fStream = new FileStream(path + "\\" + userName + ".txt", FileMode.OpenOrCreate, FileAccess.Read);
                                StreamReader streamReader = new StreamReader(fStream);
                                data = streamReader.ReadToEnd();

                                textFile tFIle = new textFile(data);
                                tFIle.text = data;
                                tFIle.userName = userName;
                                tFIle.Type = (int)FileDataType.텍스트파일;
                                
                                sendBuffer = FileData.Serialize(tFIle);
                                m_NetStream[count].Write(sendBuffer, 0, sendBuffer.Length);
                                m_NetStream[count].Flush();
                                streamReader.Close();
                                fStream.Close();

                                mutex[count] = true;
                            }

                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
               
            }


        }

        public string Get_myIp()
        {
            IPHostEntry host = Dns.GetHostByName(Dns.GetHostName());
            string myIp = host.AddressList[0].ToString();
            return myIp;
        }

        private void server_stop()
        {
            for (int i = 0; i < 32; i++)
            {
                if (thread_start[i])
                {
                    m_Listener[i].Stop();
                    m_Thread[i].Abort();
                }
                if (Network_start[i])
                    m_Listener[i].Stop();
            }
            if (request_start)
                request.Abort();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            server_stop();
        }

        private void findPath_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            path = folderBrowserDialog1.SelectedPath;
            path_text_box.Text = path;
        }
    }
}
